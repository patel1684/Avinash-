# jsapi4x
ArcGIS Javascript API 4.x YouTube Series
ArcGIS Javascript API has been there for a while, allowing people to author rich geo-enabled web applications. Its time to take break from ArcObjects and jump into this. I gotta say I'm having so much fun with Javascript, I didn't know that I'm going to love this language.


We are going to have so much fun with this.

# How to use this repo?
* Install Node Js on your mac or windows
* Install git command line so you can run the command lines of git
* Open command line or terminal and go to your favorite folder where you want this repo to be there.
* git clone https://github.com/hnasr/jsapi4x.git
* cd jsapi4x
* npm install
* npm run start
* Then open a browser http://localhost:8080/ig.html

Enjoy

YouTube Series here

https://www.youtube.com/watch?v=rft4ZecPQcI&index=20&list=PLQnljOFTspQUppK8iiIuoQJTAj436IWQz
